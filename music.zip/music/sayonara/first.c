#include<stdio.h>
#include<ctype.h>
int numofproductions;
char productionset[20][20];
void addresult(char result[],char val){
	int i;
	for(i=0;result[i]!='\0';i++){
		if(result[i]==val)
			return;
	}
	result[i]=val;
	result[i+1]='\0';
}
void first(char* result,char ch){
	char subresult[20];
	int foundepsilon=0;
	subresult[0]='\0';
	result[0]='\0';
	int i,j,k;
	if(!(isupper(ch))){
		addresult(result,ch);
	}
	for(i=0;i<numofproductions;i++){
		if(productionset[i][0]==ch){
			if(productionset[i][2]=='$') {
				addresult(result,'$');
			}
			else{
				j=2;
				while(productionset[i][j]!='\0'){
					foundepsilon=0;
					first(subresult,productionset[i][j]);
					for(k=0;subresult[k]!='\0';k++)
						addresult(result,subresult[k]);
					for(k=0;subresult[k]!='\0';k++){
						if(subresult[k]=='$'){
							foundepsilon=0;
							break;
						}
					}
					if(!foundepsilon) break;
					j++;
				}
			}
		}
	}
	return ;
}
void main(){
	char ch,choice,result[20];
	int i;
	printf("enter no of productions");
	scanf("%d",&numofproductions);
	for(i=0;i<numofproductions;i++){
		printf("enter productions of %d",i+1);
		scanf("%s",productionset[i]);
	}
	do{
		printf("\n find first of:");
		scanf(" %c",&ch);
		first(result,ch);
		printf("\n first(%c) = {");
		for(i=0;result[i]!='\0';i++){
			printf("%c ",result[i]);
		}
		printf("} \n");
		printf("enter y to continue");
		scanf(" %c",&choice);
	}while(choice=='y' || choice=='Y');
}

/*enter no of productions9
enter productions of 1S=ACB
enter productions of 2S=Cbb
enter productions of 3S=Ba
enter productions of 4A=da
enter productions of 5A=BC
enter productions of 6B=g
enter productions of 7B=$
enter productions of 8C=h
enter productions of 9C=$

 find first of:S

 first(S) = {d g $ h }
enter y to continuey

 find first of:A

 first(A) = {d g $ }
enter y to continuey

 find first of:B

 first(B) = {g $ }
enter y to continuey

 find first of:C

 first(C) = {h $ }
enter y to continuey

 find first of:A

 first(A) = {d g $ }
enter y to continuey

 find first of:S

 first(S) = {d g $ h }
enter y to continuen*/

/*enter no of productions4
enter productions of 1S=aB
enter productions of 2S=bA
enter productions of 3A=c
enter productions of 4B=d

 find first of:S

 first(S) = {a b }
enter y to continuey

 find first of:A

 first(A) = {c }
enter y to continuey

 find first of:B

 first(B) = {d }
enter y to continuen*/
