/* this is message*/
void main(){
	//declaration
	printf("hello");
	//end
}
