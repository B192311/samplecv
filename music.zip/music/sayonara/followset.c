 #include<stdio.h>
 #include<ctype.h>
 #include<string.h>
 char prodset[20][20],result[20];
 int n,m=0;
 void follow(char);
 void first(char);
 void addresult(char);
 void addresult(char c){
 	int i;
 	for(i=0;i<m;i++){
 		if(result[i]==c)
 		return;
	 }
	 result[m++]=c;
 }
 void first(char c){
 	if(!(isupper(c))){
 		addresult(c);
	 }
	 int i;
	 for(i=0;i<n;i++){
	 	if(prodset[i][0]==c){
	 		if(prodset[i][2]=='$'){
	 			follow(prodset[i][0]);
			 }
			 else if(islower(prodset[i][2])){
			 	addresult(prodset[i][2]);
			 }
			 else{
			 	first(prodset[i][2]);
			 }
		 }
	 }
 }
 void follow(char c){
 	int i,j;
 	if(prodset[0][0]==c){
 		addresult('$');
	 }
	 for(i=0;i<n;i++){
	 	for(j=2;j<strlen(prodset[i]);j++){
	 		if(prodset[i][j]==c){
	 			if(prodset[i][j+1]!='\0'){
	 				first(prodset[i][j+1]);
				 }
				 if(prodset[i][j+1]=='\0'){
				 	follow(prodset[i][0]);
				 }
			 }
		 }
	 }
 }
 void main(){
 	printf("enter no of productions");
 	scanf("%d",&n);
 	char c,choice;
 	int i;
 	for(i=0;i<n;i++){
 		printf("enter production %d : ",i+1);
 		scanf(" %s",prodset[i]);
	 }
	 do{
	 	printf("find follow of");
	 	scanf(" %c",&c);
	 	m=0;
	 	follow(c);
	 	printf("\nfollow(%c) : {",c);
	 	for(i=0;i<m;i++){
	 		printf(" %c",result[i]);
		 }
		 printf("}\n");
		 printf("press y to continue");
		 scanf(" %c",&choice);
	 }while(choice=='y' || choice=='Y');
 }
 /*enter no of productions5
enter production 1 : S=aABb
enter production 2 : A=c
enter production 3 : A=$
enter production 4 : B=d
enter production 5 : B=$
find follow ofS

follow(S) : { $}
press y to continuey
find follow ofA

follow(A) : { d b}
press y to continuey
find follow ofB

follow(B) : { b}
press y to continuen*/
