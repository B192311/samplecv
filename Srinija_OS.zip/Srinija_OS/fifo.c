#include<stdio.h>
int checkHit(int frames[],int f,int page)
{
	int i;
	for( i=0;i<f;i++)
	{
		if(page==frames[i])
			return 1;
	}
	return -1;
}
int main()
{
	int n,i;
	printf("enter number of pages: ");
	scanf("%d",&n);
	int ref[n];
	printf("enter reference string: ");
	for( i=0;i<n;i++)
	{
		scanf("%d",&ref[i]);
	}
	int f;
	printf("enter number of frames: ");
	scanf("%d",&f);
	int frames[f];
	
	for( i=0;i<f;i++)
	{
		frames[i]=-1;
	}
	
	int hit=0,pf=0;
	printf("frame1\tframe2\tframe3\n");
	for( i=0;i<n;i++)
	{
		int index=checkHit(frames,f,ref[i]);
		if(index==1)
		{
			hit++;
		}
		else
		{
			frames[pf%f]=ref[i];
			pf++;
		}
//		for( i=0;i<f;i++)
//		{
//			printf("%d\t",frames[i]);
//		}
//		printf("\n");
	}
	printf("Hits: %d",hit);
	printf("\nPage faults: %d",pf);
}
