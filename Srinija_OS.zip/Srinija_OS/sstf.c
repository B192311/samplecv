#include<stdio.h>
#include<stdlib.h>
int main()
{
    int n,i,j;
    printf("Enter number of tracks: ");
    scanf("%d",&n);
    int a[n];
    printf("Enter queue: ");
    for( i=0;i<n;i++)
    {
        scanf("%d",&a[i]);
    }
    int hp;
    printf("Enter head pointer: ");
    scanf("%d",&hp);
    int index,sum=0,diff;
    for( i=0;i<n;i++)
    {
        int mindiff=999;
        for( j=0;j<n;j++)
        {
            diff=abs(hp-a[j]);
            if(diff<mindiff)
            {
                mindiff=diff;
                index=j;
            }
        }
        hp=a[index];
        printf("%d ",a[index]);
        sum+=mindiff;
        a[index]=999;
    } 
    printf("\nHead movements: %d",sum);
}
