#include<stdio.h>
int main()
{
	int n,i;
	printf("enter number of pages: ");
	scanf("%d",&n);
	int ref[n],visit[n];
	printf("enter reference string: ");//7 0 1 2 0 3 0 4 2 3 0 3 2 1 2 0 1 7 0 1
	for( i=0;i<n;i++)
	{
		scanf("%d",&ref[i]);
		visit[i]=0;
	}
	int f;
	printf("enter frames: ");
	scanf("%d",&f);
	
	int frames[f],count[f];
	for( i=0;i<f;i++)
	{
		frames[i]=-1;
		count[i]=0;
	}
	printf("\nframe1\tframe2\tframe\n");
	int c=1,hit=0,pf=0,j,k;
	for( i=0;i<n;i++)
	{
		for( j=0;j<f;j++)
		{
			if(frames[j]==ref[i])
			{
				visit[i]=1;
				hit++;
				count[j]=c;
				c++;
			}
		}
		if(visit[i]==0)
		{
			if(i<f)
			{
				frames[i]=ref[i];
				count[i]=c;
				c++;
			}
			else
			{
				int min=999,index;
				for( k=0;k<f;k++)
				{
					if(count[k]<min)
					{
						min=count[k];
						index=k;
					}
				}
				frames[index]=ref[i];
				count[index]=c;
				c++;
			}
			pf++;
		}
		for( k=0;k<f;k++)
		{
			printf("%d\t",frames[k]);
		}
		printf("\n");
	}
	printf("Page faults: %d ",pf);
	printf("Hits: %d ",hit);
}
