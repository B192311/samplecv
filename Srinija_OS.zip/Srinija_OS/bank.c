#include<stdio.h> 

void main() 
{ 
 int n,m; 
 printf("enter the number of process:"); 
 scanf("%d",&n); 
 printf("no of resources:\n"); 
 scanf("%d",&m); 
 int i,j,k,finish[n],allocation[10][10],max[10][10],need[10][10],work[10][10]; 
 for(i=0;i<n;i++) 
 finish[i]=0; 
 printf("enter the allocation matrix\n"); 
 for(i=0;i<n;i++) 
 { 
  for(j=0;j<m;j++) 
  { 
   scanf("%d",&allocation[i][j]); 
  } 
 } 
 printf("enter the max matrix\n"); 
 for(i=0;i<n;i++) 
 { 
  for(j=0;j<m;j++) 
  { 
   scanf("%d",&max[i][j]); 
  } 
 }  printf("enter the available resources:\n"); 
 for(i=0;i<1;i++) 
 { 
  for(j=0;j<m;j++) 
  { 
    scanf("%d",&work[i][j]); 
  } 
   }for(i=0;i<n;i++) 
 { 
 for(j=0;j<m;j++) 
  { 
   need[i][j]=max[i][j]-allocation[i][j]; 
  } 
 } 
 for(i=0;i<n;i++) 
 { 
  for(j=0;j<m;j++) 
  { 
   printf("%d\t",need[i][j]); 
  } 
  printf("\n"); 
 } 
 int count=0; 
 int c=0; 
 printf("The sequence is: "); 
 for(i=0;;i++) 
 { 
  count=0; 
  if(finish[i]==0) 
  { 
    for(k=0;k<m;k++) 
   { 
    if(need[i][k]<=work[0][k]) 
     { 
      count++; 
     } 
    } 
  if(count==m) 
  { 
   for(k=0;k<m;k++) 
   { 
    work[0][k]=work[0][k]+allocation[i][k]; 
    finish[i]=1; 
   } 
   c++; 
   
   printf("%d\t",i); 
  }  } 
  if(c==n) 
  break; 
  if(i==n-1) 
  { 
   i=0;  }  
}  }
