#include<stdio.h>
#include<stdlib.h>
void sort(int a[],int n)
{
	int i,j;
    for( i=0;i<n-1;i++)
    {
        for( j=0;j<n-1-i;j++)
        {
            if(a[j]>a[j+1])
            {
                int temp=a[j];
                a[j]=a[j+1];
                a[j+1]=temp;
            }
        }
    }
}int Clook(int a[],int n,int hp,int dir)
{
    int i,sum=0,ans;
    if(dir==1)
    {
        i=0;
        while(a[i]<hp)
        {
            ans=a[i];
            i++;
        }
        sum=abs(hp-a[n-1])+abs(a[n-1]-a[0])+abs(a[0]-ans);
    }
    else
    {
        i=n-1;
        while(a[i]>hp)
        {
            ans=a[i];
            i--;
        }
        sum=abs(hp-a[0])+abs(a[0]-a[n-1])+abs(a[n-1]-ans);
    }
}
int main()
{
    int n,i;
    printf("Enter queue size: ");
    scanf("%d",&n);
    int a[n];
    printf("Enter queue: ");
    for( i=0;i<n;i++)
    {
        scanf("%d",&a[i]);
    }
    int hp;
    printf("Enter head pointer: ");
    scanf("%d",&hp);
    int dir;
    printf("Enter direction 1.Right 2.Left: ");
    scanf("%d",&dir);
    sort(a,n);
    int sum=Clook(a,n,hp,dir);
    printf("Total head movements: %d",sum);
}
