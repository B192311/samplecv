#include<stdio.h>
struct process{
    int pro,at,bt,ct,tat,wt,visit;
};
int findprocess(struct process p[],int n,int t)
{
    int min=999;
    int index=-1;
    for(int i=0;i<n;i++)
    {
        if(p[i].at<=t && p[i].visit==0)
        {
            if(p[i].bt<min)
            {
                min=p[i].bt;
                index=i;
            }
            if(p[i].bt==min)
            {
                if(p[i].at<p[index].at)
                {
                    index=i;
                }
            }
        }
    }
    return index;
}
int main()
{
    int n,t=0;
    float atat,awt;
    printf("enter number of proces: ");
    scanf("%d",&n);
    struct process p[n];
    printf("enter process,arrival time,burst time: ");
    for(int i=0;i<n;i++)
    {
        scanf("%d%d%d",&p[i].pro,&p[i].at,&p[i].bt);
        p[i].visit=0;
    }
    printf("\nGanttchat: ");
    int k=0;
    while(k<n)
    {
        int index=findprocess(p,n,t);
        if(index!=-1)
        {
            p[index].ct=t+p[index].bt;
            t=p[index].ct;
            p[index].tat=p[index].ct-p[index].at;
            p[index].wt=p[index].tat-p[index].bt;
            p[index].visit=1;
            atat+=p[index].tat;
            awt+=p[index].wt;
            k++;
            printf("%d ",p[index].pro);
        }
        else
        {
            t=t+1;
            printf("- ");
        }
    }
    printf("\nPro\tAt\tBT\tCT\tTAT\tWT\n");
    for(int i=0;i<n;i++)
    {
        printf("%d\t%d\t%d\t%d\t%d\t%d\n",p[i].pro,p[i].at,p[i].bt,p[i].ct,p[i].tat,p[i].wt);
    }
    printf("Average turn around time: %f",atat);
    printf("\nAverage waiting time: %f",awt);
}
