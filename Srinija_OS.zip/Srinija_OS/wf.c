#include<stdio.h>
int main()
{
	int n;
	printf("enter number of processors: ");
	scanf("%d",&n);
	int p[n];
	printf("enter size of each processor: ");
	for(int i=0;i<n;i++)
		scanf("%d",&p[i]);
	
	int m;
	printf("enter number of blocks: ");
	scanf("%d",&m);
	int b[m];
	printf("enter size of each blocks: ");
	for(int i=0;i<m;i++)
		scanf("%d",&b[i]);
	
	int visit[m];
	for(int i=0;i<m;i++)
		visit[i]=0;
	int allocate[m];
	for(int i=0;i<m;i++)
		allocate[i]=-1;
	
	int inf=0;
	int index;
	for(int i=0;i<n;i++)
	{
		int max=0;
		index=999;
		for(int j=0;j<m;j++)
		{
			if(visit[j]==0 && b[j]>=p[i] && b[j]>max)
			{
				max=b[j];
				index=j;
			}
		}
		allocate[index]=i+1;
		visit[index]=1;
		if(index!=999)
			inf+=(b[index]-p[i]);
	}
	printf("\nprocess\t\tblocksize\n");
	for(int i=0;i<m;i++)
	{
		printf("\n%d\t\t%d\n",allocate[i],b[i]);
	}
	
	printf("\nInternal fragmentation: %d",inf);
	int ef=0;
	for(int i=0;i<m;i++)
	{
		if(visit[i]!=1)
		{
			ef+=b[i];
		}
	}
	printf("\nExternal fragmentation: %d",ef);

}
