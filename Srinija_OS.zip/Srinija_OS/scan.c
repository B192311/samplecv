#include<stdio.h>
#include<stdlib.h>
void sort(int a[],int n)
{
	int i,j;
    for( i=0;i<n-1;i++)
    {
        for( j=0;j<n-1-i;j++)
        {
            if(a[j]>a[j+1])
            {
                int temp=a[j];
                a[j]=a[j+1];
                a[j+1]=temp;
            }
        }
    }
}
int scan(int a[],int n,int hp,int dir,int t)
{
    int sum=0;
    if(dir==1)
    {
        sum=abs(hp-(t-1))+abs((t-1)-a[0]);
    }
    else
    {
        sum=abs(hp-0)+abs(0-a[n-1]);
    }
    return sum;
}
int main()
{
    int n,i;
    printf("Enter queue size: ");
    scanf("%d",&n);
    int a[n];
    printf("Enter Queue: ");
    for( i=0;i<n;i++)
    {
        scanf("%d",&a[i]);
    }
    int t;
    printf("Enter track size: ");
    scanf("%d",&t);
    int hp;
    printf("Enter head pointer: ");
    scanf("%d",&hp);
    sort(a,n);
    int dir;
    printf("Enter Direction 1.Right 2.Left: ");
    scanf("%d",&dir);
    int sum=scan(a,n,hp,dir,t);
    printf("Total head movements: %d",sum);
}
