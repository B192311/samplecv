#include<stdio.h>
#include<stdlib.h>
void sort(int a[],int n)
{
	int i,j;
    for( i=0;i<n-1;i++)
    {
        for( j=0;j<n-1-i;j++)
        {
            if(a[j]>a[j+1])
            {
                int temp=a[j];
                a[j]=a[j+1];
                a[j+1]=temp;
            }
        }
    }
}
int look(int a[],int n,int hp,int dir)
{
    int sum=0;
    if(dir==1)
    {
        sum=abs(hp-a[n-1])+abs(a[n-1]-a[0]);
    }
    else
    {
        sum=abs(hp-a[0])+abs(a[0]-a[n-1]);
    }
    return sum;
}
int main()
{
    int n,i;
    printf("Enter queue size: ");
    scanf("%d",&n);
    int a[n];
    printf("Enter queue: ");
    for( i=0;i<n;i++)
    {
        scanf("%d",&a[i]);
    }
    int hp;
    printf("Enter head pointer: ");
    scanf("%d",&hp);
    sort(a,n);
    int dir;
    printf("Enter direction 1.Right 2.Left: ");
    scanf("%d",&dir);
    int sum=0;
    sum=look(a,n,hp,dir);
    printf("Total head movements: %d",sum);
}
