#include<stdio.h>
struct process{
    int pro,at,bt,ct,tat,wt,dbt,i;
};
int findprocess(struct process p[],int t,int n)
{
    int min=999,index=-1,i;
    for( i=0;i<n;i++)
    {
        if(p[i].at<=t && p[i].bt!=0)
        {
            if(p[i].bt<min)
            {
                min=p[i].bt;
                index=i;
            }
            if(p[i].bt==min)
            {
                if(p[i].at<p[index].at)
                {
                    index=i;
                }
            }
        }
    }
    return index;
}
int main()
{
    int n,k=0,t=0,sum=0,i;
    printf("Enter number of process: ");
    scanf("%d",&n);
    struct process p[n];
    printf("Enter arrival time,burst time: ");
    for( i=0;i<n;i++)
    {
        scanf("%d%d",&p[i].at,&p[i].bt);
        p[i].dbt=p[i].bt;
        p[i].pro=i+1;
        sum+=p[i].bt;
    }
    float atat=0;
    float awt=0;
    while(k<sum)
    {
        int index=findprocess(p,t,n);
        if(index!=-1)
        {
            p[index].ct=t+1;
            p[index].bt=p[index].bt-1;
            t=p[index].ct;
            k++;
            printf("%d ",p[index].pro);
        }
        else
        {
            t=t+1;
            printf("-");
        }
    }
    for( i=0;i<n;i++)
    {
            p[i].tat=p[i].ct-p[i].at;
			p[i].wt=p[i].tat-p[i].dbt;
            atat+=p[i].tat;
			awt+=p[i].wt;
    }
    printf("\nPro\tAT\tBT\tCT\tTAT\tWT\n");
	for( i=0;i<n;i++)
	{
		printf("%d\t%d\t%d\t%d\t%d\t%d\n",p[i].pro,p[i].at,p[i].dbt,p[i].ct,p[i].tat,p[i].wt);
	}
	printf("Average turn around time: %f",atat/n);
	printf("Average waiting time: %f",awt/n);
}
