#include<stdio.h>
#define size 10
int q1[size],q2[size],f1=-1,r1=-1,f2=-1,r2=-1;
int c=0;

void enqueue1(int val){
	if(f1==-1 && r1==-1){
		f1=r1=0;
		q1[r1]=val;
	}
	else{
		q1[++r1]=val;
	}
}

void enqueue2(int val){
	if(f2==-1 && r2==-1){
		f2=r2=0;
		q2[r2]=val;
	}
	else{
		q2[++r2]=val;
	}
}

int dequeue1(){
	if(f1==r1){
		f1=r1=-1;
	}
	else{
		return q1[f1++];
	}
}

int dequeue2(){
	if(f2==r2){
		f2=r2=-1;
	}
	else{
		return q2[f2++];
	}
}

void push(int val){
	enqueue1(val);
	c++;
}

void pop(){
	for(int i=0;i<c;i++){
		int a=dequeue1();
		enqueue2(a);
	}
	dequeue1();
	f1=r1=-1;
	c--;
	for(int i=f2;i<c;i++){
		int b=dequeue2();
		enqueue1(b);
	}
	f2=r2=-1;
}

void display(){
	if(f1==-1 && r1==-1){
		printf("list is empty");
	}
	else{
		for(int i=r1;i>-1;i--){
			printf("%d\t",q1[i]);
		}
	}
}

int main(){
	push(10);
	push(11);
	push(12);
	display();
	printf("\n");
	pop();
	display();
	printf("\n");
	pop();
	display();
	printf("\n");
	pop();
	display();
	printf("\n");
	push(12);
	display();
	printf("\n");
	push(14);
	display();
	printf("\n");
}
