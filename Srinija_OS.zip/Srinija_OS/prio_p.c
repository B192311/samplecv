#include<stdio.h>
struct process{
    int pro,pri,at,bt,ct,tat,wt,dbt;
};
int findprocess(struct process p[],int t,int n)
{
    int min=999,index=-1;
    for(int i=0;i<n;i++)
    {
        if(p[i].at<=t && p[i].bt!=0)
        {
            if(p[i].pri<min)
            {
                min=p[i].pri;
                index=i;
            }
            if(p[i].pri==min)
            {
                if(p[i].at<p[index].at)
                {
                    index=i;
                }
            }
        }
    }
    return index;
}
int main()
{
    int n,k=0,t=0,sum=0;
    printf("Enter number of process: ");
    scanf("%d",&n);
    struct process p[n];
    printf("Enter priority,arrival time,burst time: ");
    for(int i=0;i<n;i++)
    {
        scanf("%d%d%d",&p[i].pri,&p[i].at,&p[i].bt);
        p[i].dbt=p[i].bt;
        p[i].pro=i+1;
        sum+=p[i].bt;
    }
    float atat=0;
    float awt=0;
    while(k<sum)
    {
        int index=findprocess(p,t,n);
        if(index!=-1)
        {
            p[index].ct=t+1;
            p[index].bt=p[index].bt-1;
            t=p[index].ct;
            k++;
            printf("%d ",p[index].pro);
        }
        else
        {
            t=t+1;
            printf("-");
        }
    }
    for(int i=0;i<n;i++)
    {
            p[i].tat=p[i].ct-p[i].at;
			p[i].wt=p[i].tat-p[i].dbt;
            atat+=p[i].tat;
			awt+=p[i].wt;
    }
    printf("\nPro\tAT\tBT\tCT\tTAT\tWT\n");
	for(int i=0;i<n;i++)
	{
		printf("%d\t%d\t%d\t%d\t%d\t%d\n",p[i].pro,p[i].at,p[i].bt,p[i].ct,p[i].tat,p[i].wt);
	}
	printf("Average turn around time: %f",atat/n);
	printf("Average waiting time: %f",awt/n);
}