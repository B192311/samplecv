#include<stdio.h>
#include<stdlib.h>
void sort(int a[],int n)
{
	int i,j;
    for( i=0;i<n-1;i++)
    {
        for( j=0;j<n-i-1;j++)
        {
            if(a[j]>a[j+1])
            {
                int temp=a[j];
                a[j]=a[j+1];
                a[j+1]=temp;
            }
        }
    }
}
int Cscan(int a[],int n,int hp,int dir,int t)
{
    int sum=0,ans,i;
    if(dir==1)
    {
        i=0;
        while(a[i]<hp)
        {
            ans=a[i];
            i++;
        }
        sum=abs(hp-(t-1))+abs((t-1)-0)+abs(0-ans);
    }
    else
    {
        i=n-1;
        while(a[i]>hp)
        {
            ans=a[i];
            i--;
        }
        sum=abs(hp-0)+abs(0-(t-1))+abs((t-1)-ans);
    }
}
int main()
{
    int n,t,i;
    printf("Enter track size: ");
    scanf("%d",&t);
    printf("Enter queue size: ");
    scanf("%d",&n);
    int a[n];
    printf("Enter queue: ");
    for( i=0;i<n;i++)
    {
        scanf("%d",&a[i]);
    }
    int hp;
    printf("Enter head pointer: ");
    scanf("%d",&hp);
    int dir;
    printf("Enter direction 1.Right 2.Left: ");
    scanf("%d",&dir);
    sort(a,n);
    int sum=Cscan(a,n,hp,dir,t);
    printf("Total head movements: %d",sum);
}
