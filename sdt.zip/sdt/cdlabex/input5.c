#include<stdio.h>
void main(){
//single line comment
/*
*/
//hello
int a;
printf("hello");
scanf("%d",a);
printf("jai cngrs");
printf("jai revanth");
}
