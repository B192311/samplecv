#include<stdio.h>
void main(){
//single line comment
/*
*/
//hello
int a;
("hello");
("%d",a);
("jai cngrs");
("jai revanth");
}
