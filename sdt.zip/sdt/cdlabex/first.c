#include<stdio.h>
#include<ctype.h>
int nop;char production[10][10];
void first(char[],char);
void addtores(char[],char);
void main(){
printf("enter no.of production");
scanf("%d",&nop);
printf("enter your productions");
for(int i=0;i<nop;i++){
   scanf("%s",production[i]);
  }
  int choice;char c;
  char result[20];
  do{
     printf("enter the char u want to find first");
     scanf(" %c",&c);
     first(result,c);
     printf("first of %c {",c);
     for(int i=0;result[i]!='\0';i++){
        printf(" %c,",result[i]);
        }
        printf("}");
        printf("presss 0 to continue:");
        scanf("%d",&choice); 
  }while(choice!=0);
}
void first(char res[], char ch){
  char subres[10];
  res[0]='\0';
  subres[0]='\0';
  int i,j,k;
   if(!isupper(ch)){
      addtores(res,ch);
      return ;
    }
    for(i=0;i<nop;i++){ 
    	if(production[i][0]==ch){
    	   if(production[i][2]=='$'){
    	       addtores(res,'$');
    	   }
    	   else{
    	   j=2;
    	   while(production[i][j]!='\0'){
    	       int epsi=0;
	    	   first(subres,production[i][j]);
	    	   for(k=0;subres[k]!='\0';k++){
	    	     addtores(res,subres[k]);
	    	     }
	    	     for(k=0;subres[k]!='\0';k++){
		    	   if(subres[k]=='$'){
		    	     epsi=1;
		    	     break;
	    	           }
	    	     }      
	    	              if(!epsi)
	    	               break;
	    	                j++; 
	    	          
    	     
    	   }
    	  
    	      
    	 }
       
      }
   }
}
void addtores(char res[],char ch){
int k=0;
for(k=0;res[k]!='\0';k++)
    if(res[k]==ch) return;
res[k]=ch;
res[k+1]='\0';    
}
