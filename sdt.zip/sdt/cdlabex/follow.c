#include<stdio.h>
#include<ctype.h>
#include<string.h>
int n,m=0;
char prod[10][10];
char res[10];
void first(char ch);
void follow(char ch);
void addtores(char ch);
int main(){
   int i;
   printf("enter no of productions");
   scanf("%d",&n);
   printf("enter production rules");
   for(int i=0;i<n;i++) scanf(" %s",prod[i]);
   int choice;
   do{
        int choice;char ch;
   	printf("enter char to find follow");
   	scanf(" %c",&ch);
   	follow(ch);
   	printf("follow of %c {",ch);
   	for(int i=0;i<m;i++)
   	   printf(" %c",res[i]);
   	printf("}");
   	printf("press 0 to exit");
   	scanf("%d",&choice);
   }while(choice==0);
}
void follow(char ch){
   if(prod[0][0]==ch)addtores('$');
   int i,j;
   for(int i=0;i<n;i++){
       for(int j=2;j<strlen(prod[i]);j++){
           if(prod[i][j]==ch){
           	if(prod[i][j+1]!='\0'){
           		first(prod[i][j+1]);
           	}
           	if(prod[i][j+1]=='\0'){
           		follow(prod[i][0]);
           	}
           }
       }
   }
}
void first(char ch){
   if(!isupper(ch)){
   	addtores(ch);
   }
   int i;
   for(i=0;i<n;i++){
   	if(prod[i][0]==ch){
   	   if(prod[i][2]=='$') follow(prod[i][0]);
   	  else if(islower(prod[i][2])) addtores(prod[i][2]);
   	  else first(prod[i][2]);
   	   
   	}
   }
}
void addtores(char ch){
   int k;
   for(k=0;k<m;k++){
     if(res[k]==ch) return;
   }
   res[m++]=ch;
}
