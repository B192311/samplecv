#include<stdio.h>
int main()
{
	int n,i,j;
	printf("enter number of process: ");
	scanf("%d",&n);
	int p[n];
	printf("enter size of each process: ");
	for( i=0;i<n;i++)
		scanf("%d",&p[i]);
		
	int m;
	printf("enter number of blocks: ");
	scanf("%d",&m);
	int b[m],visit[m],allocate[m];
	printf("enter size of each block: ");
	for( i=0;i<m;i++)
	{
		scanf("%d",&b[i]);
		visit[i]=0;
		allocate[i]=-1;
	}
	int inf=0;
	for( i=0;i<n;i++)
	{
		int min=999;
		int index=999;
		for( j=0;j<m;j++)
		{
			if(visit[j]==0 && b[j]>=p[i] && b[j]<min)
			{
				min=b[j];
				index=j;
			}
		}	
		allocate[index]=i+1;
		visit[index]=1;
		if(index!=999)
			inf+=(b[index]-p[i]);
	}
	printf("\nprocess\tblocksize\n");
	for( i=0;i<m;i++)
	{
		printf("%d\t%d\n",allocate[i],b[i]);
	}
	
	printf("\nInternal fragmentation: %d",inf);
	int ef=0;
	for( i=0;i<m;i++)
	{
		if(visit[i]!=1)
		{
			ef+=b[i];
		}
	}
	printf("\nExternal fragmentation: %d",ef);
}
