#include<stdio.h>
struct process{
	int pro,at,bt,ct,tat,wt,dbt;
};
struct process queue[100];
int front=-1,rear=-1;
void enque(struct process p)
{
	if(front==-1 && rear==-1)
	{
		front=rear=0;
		queue[rear]=p;
	}
	else
	{
		rear++;
		queue[rear]=p;
	}
}
int deque()
{
	int res;
	if(front==rear)
	{
		res=queue[front].pro;
		front=rear=-1;
	}
	else
	{
		res=queue[front].pro;
		front++;
	}
	return res;
}
void sort (struct process p[],int n)
{
	for(int i=0;i<n-1;i++)
	{
		for(int j=0;j<n-1-i;j++)
		{
			if(p[j].at>p[j+1].at)
			{
				struct process temp=p[j];
				p[j]=p[j+1];
				p[j+1]=temp;
			}
		}
	}
}
void solve(struct process p[],int n,int ideal,int tq)
{
	printf("Ganttchat: ");
	int sum=ideal;
	int j=1;
	enque(p[0]);	
	while(front!=-1 && rear!=-1)	//until the queue is empty 
	{
		for(int i=0;i<n;i++)
		{
			if(p[i].pro==queue[front].pro)	//front processor
			{
				if(p[i].bt<=tq)
				{
					sum+=p[i].bt;
					p[i].ct=sum;
				}
				else
				{
					sum+=tq;
					p[i].bt-=tq;
					while(p[j].at<=sum && j<n)	//enque all processors which arrived before last processor's ct (all processors are n so j<n)
					{
						enque(p[j]);
						j++;
					}
					enque(p[i]);	//if again enqueue the curent processor
				}
				break;
			}
		}
		int res=deque();
		printf("P%d ",res);
	}
}
int main()
{
	int n;
	printf("Enter number of process: ");
	scanf("%d",&n);
	struct  process p[n];
	printf("Enter arrival time,burst time: ");
	for(int i=0;i<n;i++)
	{
		scanf("%d%d",&p[i].at,&p[i].bt);
		p[i].pro=i+1;
		p[i].dbt=p[i].bt;
	}
	int tq;
	printf("Enter time quantum: ");
	scanf("%d",&tq);
	sort(p,n);
	int ideal=0;
	if(p[0].at==0)
	{
		solve(p,n,ideal,tq);
	}
	else
	{
		ideal=ideal+p[0].at;
		solve(p,n,ideal,tq);
	}
	float awt, atat;
    for (int i = 0; i < n; i++)
    {
        p[i].tat = p[i].ct - p[i].at;
        p[i].wt = p[i].tat - p[i].dbt;
        atat += p[i].tat;
        awt += p[i].at;
    }
    printf("\npro\tAT\tBT\tCT\tTAT\tWT\n");
	for(int i=0;i<n;i++)
		printf("%d\t%d\t%d\t%d\t%d\t%d\n",p[i].pro,p[i].at,p[i].dbt,p[i].ct,p[i].tat,p[i].wt);
	printf("Average turn around time: %f",atat/n);
	printf("\nAverage turn around time: %f",awt/n);
}
