#include<stdio.h>
#include<stdlib.h>
int main()
{
    int n,i;
    printf("Enter number of tracks: ");
    scanf("%d",&n);
    int a[n];
    printf("Enter queue: ");
    for( i=0;i<n;i++)
    {
        scanf("%d",&a[i]);
    }
    int hp;
    printf("Enter head pointer: ");
    scanf("%d",&hp);

    //printf("Travelled tracks in FCFS: ");
    int sum=0;
    sum+=abs(hp-a[0]);
    //printf("%d ",a[0]);
    for( i=1;i<n;i++)
    {
        sum+=abs(a[i-1]-a[i]);
       // printf("%d ",a[i]);
    }
    printf("Head Movements: %d",sum);
}
