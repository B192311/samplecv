#include<stdio.h>
struct process{
	int pro,at,bt,ct,tat,wt;
};
void sort(struct process p[],int n)
{
	int i;
	for( i=0;i<n;i++)
	{
		for(int j=i+1;j<n;j++)
		{
			if(p[i].at>p[j].at)
			{
				struct process temp;
				temp=p[i];
				p[i]=p[j];
				p[j]=temp;
			}
		}
	}
}
int main()
{
	int n;
	printf("enter number of process: ");
	scanf("%d",&n);
	struct process p[n];
	printf("enter process,arrival time,burst time: ");
	for(int i=0;i<n;i++)
	{
		scanf("%d%d%d",&p[i].pro,&p[i].at,&p[i].bt);
	}
	sort(p,n);
	printf("\nGanttchat: ");
	p[0].ct=p[0].at+p[0].bt;
	printf("P%d ",p[0].pro);
	for(int i=1;i<n;i++)
	{
		if(p[i].at<=p[i-1].ct)
		{
			p[i].ct=p[i-1].ct+p[i].bt;
			printf("P%d ",p[i].pro);
		}
		else
		{
			p[i].ct=p[i].at+p[i].bt;
			printf("- ");
		}
	}
	float atat=0,awt=0;
	for(int i=0;i<n;i++)
	{
		p[i].tat=p[i].ct-p[i].at;
		p[i].wt=p[i].tat-p[i].bt;
		atat+=p[i].tat;
		awt+=p[i].wt;
	}
	printf("\npro\tAT\tBT\tCT\tTAT\tWT\n");
	for(int i=0;i<n;i++)
	{
		printf("%d\t%d\t%d\t%d\t%d\t%d\n",p[i].pro,p[i].at,p[i].bt,p[i].ct,p[i].tat,p[i].wt);
	}
	printf("Average turn around time: %f",atat/n);
	printf("\nAverage waiting time: %f",awt/n);
}
