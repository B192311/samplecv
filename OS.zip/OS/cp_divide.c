#include<stdio.h>
#include<math.h>
#include<limits.h>

struct point{
	int x,y;
};

void sort(struct point p[],int n)
{
	int i,j;
	struct point temp;
	for(i=0;i<n;i++)
	{
		for(j=0;j<n-1-i;j++)
		{
			if(p[j].x>p[j+1].x)
			{
				temp=p[j];
				p[j]=p[j+1];
				p[j+1]=temp;
			}
			
		}
	}
}

float bruteforce(struct point p[],int st,int end)
{
	int i,j;
	float d,min;
	min=LONG_MAX;
	for(i=st;i<end-1;i++)
	{
		for(j=i+1;j<end;j++)
		{
			d=(float)sqrt(((p[i].x-p[j].x)*(p[i].x-p[j].x))+((p[i].y-p[j].y)*(p[i].y-p[j].y)));
			if(d<min)
				min=d;
		}
	}
	return min;
}
float closest(struct point p[],int st,int end)
{
	int mid,l=0,i;
	float min,b,k,dl,dr;
	if((end-st)<=3)
		min=bruteforce(p,st,end);
	else
	{
		mid=(st+end)/2;
		dl=(float)closest(p,st,mid);
		dr=(float)closest(p,mid+1,end);
		k=(float)dl>dr?dr:dl;
		struct point strip[50];
		l=0;
		for(i=st;i<=end;i++)
		{
			if(p[mid].x-k <=p[i].x && p[mid].x<=p[i].x+k)
			{
				strip[l++]=p[i];
			}
		}
		b=bruteforce(strip,0,l);
		min=(float)b>k?k:b;
	}
	return min;
}

int main()
{
	int i,n;
	float min;
	printf("Enter no.of points:");
	scanf("%d",&n);
	struct point p[10];
	printf("Enter co-ordinates of each point:");
	for(i=0;i<n;i++)
	{
		scanf("%d %d",&p[i].x,&p[i].y);
	}
	sort(p,n);
	min=(float)closest(p,0,n);
	printf("Minimum distance:%f\n",min);
	return 0;
}

