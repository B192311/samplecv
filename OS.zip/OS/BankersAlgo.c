#include <stdio.h>

#define MAX_PROCESSES 5
#define MAX_RESOURCES 3

int available[MAX_RESOURCES];
int maximum[MAX_PROCESSES][MAX_RESOURCES];
int allocation[MAX_PROCESSES][MAX_RESOURCES];
int need[MAX_PROCESSES][MAX_RESOURCES];
int safeSequence[MAX_PROCESSES];  // Array to store the safe sequence


// Function to check if the system is in a safe state
int isSafe(int available[], int max[][MAX_RESOURCES], int alloc[][MAX_RESOURCES], int need[][MAX_RESOURCES], int num_processes, int num_resources) {
    int work[MAX_RESOURCES];
    int finish[MAX_PROCESSES] = {0}; // Initially, no process is finished

    // Initialize work to available
    for (int i = 0; i < num_resources; i++) {
        work[i] = available[i];
    }

    int completed; 
    int count=0; // Flag to check if any process completes in an iteration

    // Check for each process
    do {
        completed = 0;  // Initialize the flag to false

        for (int i = 0; i < num_processes; i++) {
            if (!finish[i] && need[i][0] <= work[0] && need[i][1] <= work[1] && need[i][2] <= work[2]) {
                // Process can complete
                for (int j = 0; j < num_resources; j++) {
                    work[j] += allocation[i][j];
                }
                finish[i] = 1; 
                safeSequence[count++] = i;// Mark the process as finished
                completed = 1; // Set the flag to true
            }
        }
    } while (completed);

    // Check if all processes are finished
    for (int i = 0; i < num_processes; i++) {
        if (!finish[i]) {
            return 0; // Not in a safe state
        }
    }

    return 1; // In a safe state
}

int main() {
    int num_processes, num_resources;

    // Input the number of processes and resources
    printf("Enter the number of processes: ");
    scanf("%d", &num_processes);
    printf("Enter the number of resources: ");
    scanf("%d", &num_resources);

    // Input the available resources
    printf("Enter the available resources:\n");
    for (int i = 0; i < num_resources; i++) {
        scanf("%d", &available[i]);
    }

    // Input the maximum resources required by each process
    printf("Enter the maximum resources required by each process:\n");
    for (int i = 0; i < num_processes; i++) {
        printf("For process %d: ", i + 1);
        for (int j = 0; j < num_resources; j++) {
            scanf("%d", &maximum[i][j]);
        }
    }

    // Input the resources currently allocated to each process
    printf("Enter the resources currently allocated to each process:\n");
    for (int i = 0; i < num_processes; i++) {
        printf("For process %d: ", i + 1);
        for (int j = 0; j < num_resources; j++) {
            scanf("%d", &allocation[i][j]);
            need[i][j] = maximum[i][j] - allocation[i][j];
        }
    }

    // Check if the system is in a safe state
    if (isSafe(available, maximum, allocation, need, num_processes, num_resources)) {
        printf("\nThe system is in a safe state.\n");
        for(int i=0;i<MAX_PROCESSES;i++){
            printf("%d\t",safeSequence[i]);
        }
    } else {
        printf("\nThe system is not in a safe state.\n");
    }

    return 0;
}
