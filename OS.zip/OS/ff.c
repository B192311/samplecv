#include<stdio.h>
int main()
{
	int n,i,j;
	printf("enter number of processors: ");
	scanf("%d",&n);
	int p[n];
	printf("enter size of each processor: ");
	for( i=0;i<n;i++)
	{
		scanf("%d",&p[i]);
	}
	int m;
	printf("enter number of blocks: ");
	scanf("%d",&m);
	int b[m];
	printf("enter size of each block: ");
	for( i=0;i<m;i++)
	{
		scanf("%d",&b[i]);
	}
	
	int visit[m];
	for( i=0;i<m;i++)
	{
		visit[i]=0;
	}
	
	int inf=0;
	int allocate[m];
	for( i=0;i<n;i++)
	{
		for( j=0;j<m;j++)
		{
			if(b[j]>=p[i] && visit[j]==0)
			{
				allocate[j]=i+1;
				visit[j]=1;
				inf+=(b[j]-p[i]);
				break;
			}
		}
	}
	printf("\nprocess\tblocksize\n");
	for( i=0;i<m;i++)
	{
		printf("P%d\t\t%d\n",allocate[i],b[i]);
	}
	
	printf("Internal fragmentation: %d",inf);
	int ef=0;
	for( i=0;i<m;i++)
	{
		if(visit[i]!=1)
		{
			ef+=b[i];
		}
	}
	printf("\nExternal fragmentation: %d",ef);
}
